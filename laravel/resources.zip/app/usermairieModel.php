<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class usermairieModel extends Model
{
    // table usermairie
    protected $table = 'usermairie';
    public $timestamps = false;
}
