<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class articleModel extends Model
{
    //
}
