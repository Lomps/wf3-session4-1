<div class="container-fluid">
	<footer class="container">
		<div class="row">
			<div class="col-12 ">
				<ul class="nav justify-content-center ftr">
					<li class="nav-item">
						<a class="nav-link active" href="{{URL::to('/')}}/credit">
							Crédit
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="{{URL::to('/')}}/mentions-legales">
							Mentions légales
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="{{URL::to('/')}}/contactez-nous">Contacter Nous
						</a>
					</li>
				</ul>
				<p class="copy mb-0 ftr">
					&copy 2018 WebForce3
				</p>
			</div>
		</div>
	</footer>
</div>
</body>
</html>
