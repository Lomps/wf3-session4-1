@include('partials.header')

@yield('contenu principal')

@include('partials.footer')