@include('partials.header')

@yield('contenu')

</body>
</html>