@include('partials.header')

@yield('contenu')

@include('partials.footer')