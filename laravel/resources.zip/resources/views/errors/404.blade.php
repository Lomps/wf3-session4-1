@extends('layouts.mainlayout')

@section('title', 'Page non trouvée')

@section('contenu')
<main class="container">
    <section class="row">
        <div class="col">
            <h1>
                Page non trouvée
            </h1>
           <p>
               Désolé, la page que vous cherchez n'existe pas
           </p>
        </div>
    </section>
    @endsection